package net.mikexxx.pmpport;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.io.InputStreamReader;
import java.util.*;
import java.util.function.Supplier;

@Mod(PmpMod.MODID)
public class PmpMod {
    public static final String MODID = "pmp_mikexxx";
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);
    static final Map<String, List<RegistryObject<Item>>> BY_TAB = new LinkedHashMap<>();
    static final Map<String, String> TAB_ICON = new HashMap<>();
    /** fixed foliage tint per leaf block id (the original mod used fixed colours, not biome colours) */
    public static final Map<String, Integer> LEAF_TINT = new LinkedHashMap<>();
    /** plants whose overlay layer (tintindex 0) is tinted with the biome grass colour (classic ferns) */
    public static final Set<String> BIOME_TINT = new LinkedHashSet<>();

    public PmpMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        JsonArray arr;
        try (var in = new InputStreamReader(PmpMod.class.getResourceAsStream("/pmp_entries.json"))) {
            arr = JsonParser.parseReader(in).getAsJsonArray();
        } catch (Exception e) {
            throw new RuntimeException("PMP: cannot read pmp_entries.json", e);
        }
        for (String t : List.of("flowers", "plants", "crops", "aquatic", "trees", "food", "build")) BY_TAB.put(t, new ArrayList<>());
        for (JsonElement je : arr) register(je.getAsJsonObject());
        ResourceKey<CreativeModeTab> prev = null;
        int tabIndex = 0;
        for (String t : BY_TAB.keySet()) {
            final String tab = t;
            // numeric prefix keeps all PMP tabs sorted together (before other mods' tabs)
            final String tabPath = (tabIndex++) + "_" + t;
            final ResourceKey<CreativeModeTab> before = prev;
            TABS.register(tabPath, () -> {
                CreativeModeTab.Builder b = CreativeModeTab.builder()
                        .title(Component.translatable("itemGroup." + MODID + "." + tabPath))
                        .icon(() -> {
                            List<RegistryObject<Item>> l = BY_TAB.get(tab);
                            return l.isEmpty() ? new ItemStack(Items.POPPY) : new ItemStack(l.get(0).get());
                        })
                        .displayItems((params, out) -> { for (RegistryObject<Item> r : BY_TAB.get(tab)) out.accept(r.get()); });
                if (before != null) b.withTabsBefore(before);
                return b.build();
            });
            prev = ResourceKey.create(Registries.CREATIVE_MODE_TAB, new ResourceLocation(MODID, tabPath));
        }
        final ResourceKey<CreativeModeTab> lastTab = prev;
        TABS.register("all_plants", () -> CreativeModeTab.builder()
                .title(Component.translatable("itemGroup." + MODID + ".all_plants"))
                .icon(() -> {
                    Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(MODID, "flower_red"));
                    return new ItemStack(it == null || it == Items.AIR ? Items.POPPY : it);
                })
                .withTabsBefore(lastTab)
                .displayItems((params, out) -> {
                    for (String pid : ColorConfig.all()) {
                        Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(MODID, pid));
                        if (it != null && it != Items.AIR) out.accept(it);
                    }
                })
                .build());
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }

    private static PlantBlock flattened(PlantBlock b, boolean f) { return f ? b.flat() : b; }

    private static PlantBlock harvested(PlantBlock b, String h) { return h == null ? b : b.withHarvest(h); }

    private static BlockBehaviour.Properties plantProps() {
        return BlockBehaviour.Properties.of().noCollission().instabreak().randomTicks()
                .sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY);
    }

    private static BlockBehaviour.Properties woodProps() {
        return BlockBehaviour.Properties.of().strength(2.0F, 3.0F).sound(SoundType.BAMBOO_WOOD);
    }

    private static BlockBehaviour.Properties solidProps(String id) {
        String n = id;
        if (n.contains("bamboo") || n.contains("oak") || n.contains("birch") || n.contains("spruce") || n.contains("jungle")
                || n.contains("acacia") || n.contains("fruitwood") || n.contains("frtwd")) return woodProps();
        if (n.startsWith("gold") || n.startsWith("iron") || n.startsWith("diamond") || n.startsWith("lapis"))
            return BlockBehaviour.Properties.of().strength(3.0F, 6.0F).sound(SoundType.METAL);
        if (n.startsWith("ice")) return BlockBehaviour.Properties.of().strength(0.5F).sound(SoundType.GLASS);
        return BlockBehaviour.Properties.of().strength(1.5F, 6.0F).sound(SoundType.STONE);
    }

    private static void register(JsonObject o) {
        final String id = o.get("id").getAsString();
        final String kind = o.get("kind").getAsString();
        final int color = o.get("color").getAsInt();
        final String latin = o.has("latin") && !o.get("latin").isJsonNull() ? o.get("latin").getAsString() : null;
        final int stages = o.get("stages").getAsInt();
        final String tab = o.get("tab").getAsString();
        if (kind.equals("item")) {
            Item.Properties p = new Item.Properties();
            if (o.has("food") && !o.get("food").isJsonNull()) {
                JsonArray f = o.getAsJsonArray("food");
                p.food(new FoodProperties.Builder().nutrition(f.get(0).getAsInt()).saturationMod(f.get(1).getAsFloat()).build());
            }
            RegistryObject<Item> r;
            if (o.has("plant") && !o.get("plant").isJsonNull()) {
                // food item that also plants a crop (right-click block = plant, right-click air = eat)
                final String plantId = o.get("plant").getAsString();
                r = ITEMS.register(id, () -> new PmpSeedFoodItem(
                        ForgeRegistries.BLOCKS.getValue(new ResourceLocation(MODID, plantId)), p, color, latin));
            } else {
                r = ITEMS.register(id, () -> new PmpItem(p, color, latin));
            }
            BY_TAB.get(tab).add(r);
            return;
        }
        if (kind.equals("leaves") && o.has("tint")) LEAF_TINT.put(id, o.get("tint").getAsInt());
        if (o.has("biome") && o.get("biome").getAsBoolean()) BIOME_TINT.add(id);
        final boolean dwarfFlag = o.has("dwarf") && o.get("dwarf").getAsBoolean();
        final boolean directional = o.has("directional") && o.get("directional").getAsBoolean();
        final String effectName = o.has("effect") && !o.get("effect").isJsonNull() ? o.get("effect").getAsString() : null;
        final boolean flat = o.has("flat") && o.get("flat").getAsBoolean();
        final String hv = o.has("harvest") && !o.get("harvest").isJsonNull() ? o.get("harvest").getAsString() : null;
        Supplier<Block> sup;
        if (o.has("water")) {
            final JsonObject w = o.getAsJsonObject("water");
            final WaterPlantBlock.Mode wm = WaterPlantBlock.Mode.valueOf(w.get("mode").getAsString().toUpperCase());
            final int wh = w.has("h") ? w.get("h").getAsInt() : 1;
            sup = () -> new WaterPlantBlock(plantProps().noOcclusion(), wm, stages, wh);
            RegistryObject<Block> wb = BLOCKS.register(id, sup);
            BY_TAB.get(tab).add(ITEMS.register(id, () -> new PmpBlockItem(wb.get(), new Item.Properties(), color, latin, stages)));
            return;
        }
        switch (kind) {
            case "plant" -> {
                if (o.has("tree")) {
                    JsonObject t = o.getAsJsonObject("tree");
                    final String tl = t.get("log").getAsString(), tf = t.get("leaf").getAsString();
                    final boolean con = t.get("conifer").getAsBoolean();
                    final int th = t.get("h").getAsInt();
                    sup = () -> new SaplingTreeBlock(plantProps(), tl, tf, con, th);
                } else if (o.has("tall")) {
                    final int tf = o.getAsJsonObject("tall").get("from").getAsInt(), th = o.getAsJsonObject("tall").get("h").getAsInt();
                    sup = () -> new TallPlantBlock(plantProps(), stages - 1, tf, th, false);
                } else if (directional) {
                    sup = () -> new PalmettoBlock(plantProps(), stages - 1);
                } else sup = () -> flattened(harvested(new PlantBlock(plantProps(), stages - 1, PlantBlock.Type.GROUND).dwarf(dwarfFlag).withEffect(effectName), hv), flat);
            }
            case "hanging" -> {
                final int hh = o.has("h") ? o.get("h").getAsInt() : 2;
                sup = () -> new HangingPlantBlock(plantProps().noOcclusion(), hh);
            }
            case "vine" -> sup = () -> new PmpVineBlock(BlockBehaviour.Properties.of().replaceable().noCollission().randomTicks()
                    .strength(0.2F).sound(SoundType.VINE).pushReaction(PushReaction.DESTROY));
            case "climbing" -> sup = () -> new ClimbingPlantBlock(plantProps().noOcclusion());
            case "floating" -> sup = () -> flattened(new PlantBlock(plantProps(), stages - 1, PlantBlock.Type.FLOATING), flat);
            case "aqua" -> {
                if (o.has("tall")) {
                    final int tf = o.getAsJsonObject("tall").get("from").getAsInt(), th = o.getAsJsonObject("tall").get("h").getAsInt();
                    sup = () -> new TallPlantBlock(plantProps(), stages - 1, tf, th, true);
                } else sup = () -> new AquaPlantBlock(plantProps(), stages - 1);
            }
            case "leaves" -> sup = () -> new LeavesBlock(BlockBehaviour.Properties.of().strength(0.2F).randomTicks()
                    .sound(SoundType.GRASS).noOcclusion().isValidSpawn((s, g, p, t) -> false)
                    .isSuffocating((s, g, p) -> false).isViewBlocking((s, g, p) -> false));
            case "pillar" -> sup = () -> new RotatedPillarBlock(woodProps());
            case "block", "plank" -> sup = () -> new Block(woodProps());
            case "slab" -> sup = () -> new SlabBlock(woodProps());
            case "stairs" -> sup = () -> new StairBlock(() -> Blocks.OAK_PLANKS.defaultBlockState(), woodProps());
            case "fence" -> sup = () -> new FenceBlock(woodProps());
            case "gate" -> sup = () -> new FenceGateBlock(woodProps(), WoodType.BAMBOO);
            case "door" -> sup = () -> new DoorBlock(woodProps().noOcclusion(), BlockSetType.BAMBOO);
            case "ladder" -> sup = () -> new LadderBlock(BlockBehaviour.Properties.of().strength(0.4F).sound(SoundType.LADDER).noOcclusion());
            case "epiphyte" -> sup = () -> new EpiphyteBlock(BlockBehaviour.Properties.of().noCollission().instabreak().sound(SoundType.GRASS));
            case "planter" -> sup = () -> new PlanterBlock(solidProps(id).noOcclusion());
            case "flowerpot" -> sup = () -> new ShapedBlock(solidProps(id).noOcclusion(), Block.box(4.5, 0, 4.5, 11.5, 6, 11.5));
            case "wallbracket" -> sup = () -> new WallBracketBlock(solidProps(id).noOcclusion());
            case "workbench" -> sup = () -> new PottingTableBlock(woodProps().noOcclusion());
            case "pole" -> sup = () -> new PoleBlock(woodProps().noOcclusion());
            case "wall" -> sup = () -> new WallBlock(woodProps().noOcclusion());
            default -> { return; }
        }
        RegistryObject<Block> b = BLOCKS.register(id, sup);
        RegistryObject<Item> r;
        if (kind.equals("floating")) r = ITEMS.register(id, () -> new PmpFloatingItem(b.get(), new Item.Properties(), color, latin, stages));
        else if (kind.equals("door")) r = ITEMS.register(id, () -> new net.minecraft.world.item.DoubleHighBlockItem(b.get(), new Item.Properties()) {
            @Override public Component getName(ItemStack s) { return PmpItem.colored(Component.translatable(getDescriptionId()), color); }
        });
        else r = ITEMS.register(id, () -> new PmpBlockItem(b.get(), new Item.Properties(), color, latin, stages));
        BY_TAB.get(tab).add(r);
    }
}
