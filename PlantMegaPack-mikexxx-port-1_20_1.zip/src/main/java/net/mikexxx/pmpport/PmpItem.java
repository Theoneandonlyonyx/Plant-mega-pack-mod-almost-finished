package net.mikexxx.pmpport;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** Plain item with colored name + (uncolored) latin name tooltip. */
public class PmpItem extends Item {
    final int color;
    final String latin;

    public PmpItem(Properties p, int color, String latin) {
        super(p);
        this.color = color;
        this.latin = latin;
    }

    public static MutableComponent colored(Component base, int color) {
        return base.copy().withStyle(Style.EMPTY.withColor(TextColor.fromRgb(color)));
    }

    public static void tooltip(List<Component> tip, String latin, int stages) {
        if (latin != null && !latin.isEmpty()) tip.add(Component.literal(latin).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        if (stages > 1) {
            tip.add(Component.translatable("tooltip." + PmpMod.MODID + ".stages", stages).withStyle(ChatFormatting.DARK_GRAY));
            tip.add(Component.translatable("tooltip." + PmpMod.MODID + ".fertilize").withStyle(ChatFormatting.DARK_GRAY));
            tip.add(Component.translatable("tooltip." + PmpMod.MODID + ".wax").withStyle(ChatFormatting.DARK_GRAY));
        }
    }

    @Override
    public Component getName(ItemStack stack) {
        return colored(Component.translatable(this.getDescriptionId(stack)), color);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tooltip(tip, latin, 0);
    }
}
